
        // Código JS para adicionar um efeito ao passar o mouse (hover) na logo
        // const logo = document.getElementById("logo");

        // logo.addEventListener("mouseenter", function() {
        //     logo.style.transform = "scale(1.2) rotate(20deg)";
        //     logo.style.filter = "brightness(1.5)";
        // });

        // logo.addEventListener("mouseleave", function() {
        //     logo.style.transform = "scale(1) rotate(0deg)";
        //     logo.style.filter = "brightness(1)";
        // });
    